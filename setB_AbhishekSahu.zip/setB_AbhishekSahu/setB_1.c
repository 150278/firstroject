#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i,j,k,no;
     char arry[1000];
         scanf("%d",&no);
         scanf("%s",arry);
         for(i=0;i<no-1;i++)
         {
            if(arry[i]==arry[i+1])
            {
                for(j=i+2;j<no;j++)
                {
                    arry[j-2]=arry[j];
                }
                i=-1;no=no-2;
            }
         }
         if(no==0)
         {
             printf("Empty your String");
         }
         else
         {
             for(i=0;i<no;i++)
             {
                 printf("%c",arry[i]);
             }
         }


}
