#include<stdio.h>    
#include<stdlib.h>  
int main(){  
int arry[10],no,i,j,f=0;    
// printf("Enter a number : ");    
scanf("%d",&no);  

for(i=0;no>0;i++)    
    {    
        arry[i]=no%2;    
        no=no/2;    
    }    
printf("early for:");    
for(i=i-1;i>=0;i--)    
    {    
        printf("%d",arry[i]);
        f++;
    }
printf(" after:="); 
for(i=0;i<f;i++)    
    {    
        printf("%d",arry[i]);    
    } 
return 0;  
}
